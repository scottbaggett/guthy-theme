<?php
/**
 * The template used for displaying the page widget area (if enabled)
 * instead of the regular page content in page.php
 *
 * @package Milkit
 */
?>

<?php dynamic_sidebar( 'milkit-sidebar-home-content' ); ?>

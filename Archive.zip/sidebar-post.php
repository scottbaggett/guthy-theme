<?php
/**
 * The sidebar containing the single post widget area.
 *
 * This file is loaded only if we have a specialized
 * sidebar (post) for the single post template.
 *
 * @package Milkit
 */

if ( ! is_active_sidebar( 'milkit-sidebar-post' ) ) {
	return;
}
?>

<div id="secondary" class="widget-area" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
	<?php dynamic_sidebar( 'milkit-sidebar-post' ); ?>
</div><!-- #secondary -->

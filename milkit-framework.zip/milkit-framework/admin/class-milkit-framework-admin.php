<?php

/**
 * The dashboard-specific functionality of the plugin.
 *
 *
 * @since      1.0.0
 *
 * @package    Milkit_Framework
 * @subpackage Milkit_Framework/admin
 */

class Milkit_Framework_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $milkit_framework    The ID of this plugin.
	 */
	private $milkit_framework;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * General meta boxes.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      array    $meta_boxes_general    The array of fields for the general meta boxes.
	 */
	private $meta_boxes_general;

	/**
	 * Gallery meta boxes.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      array    $meta_boxes_gallery   The array of fields for the gallery.
	 */
	private $meta_boxes_gallery;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @var      string    $milkit_framework       The name of this plugin.
	 * @var      string    $version    The version of this plugin.
	 */
	public function __construct( $milkit_framework, $version ) {

		$this->milkit_framework = $milkit_framework;
		$this->version = $version;
		$this->meta_boxes_general = array();
		$this->add_meta_boxes_general();
		$this->meta_boxes_gallery = array();
		$this->add_meta_boxes_gallery();

	}

	/**
	 * Register the stylesheets for the Dashboard.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles( $hook ) {

		/**
		 * An instance of this class should be passed to the run() function
		 * defined in Milkit_Framework_Admin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Milkit_Framework_Admin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
			wp_enqueue_style( 'milkit-framework-meta-css', plugin_dir_url( __FILE__ ) . 'css/milkit-framework-meta.css', array(), $this->version, 'all' );
		}

	}

	/**
	 * Register the JavaScript for the dashboard.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts( $hook ) {

		/**
		 * An instance of this class should be passed to the run() function
		 * defined in Milkit_Framework_Admin_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Milkit_Framework_Admin_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		global $post;

		if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
			wp_enqueue_script( 'milkit-framework-meta-js', plugin_dir_url( __FILE__ ) . 'js/milkit-framework-meta.js', array( 'jquery' ), $this->version, true );
		}

	}

	/**
	 * Add the post views count column.
	 *
	 * @since    1.0.0
	 */
	public function manage_posts_columns( $columns ) {

		return array_merge( $columns, array( 'milkit_framework_post_views' => __( 'Views', 'milkit-framework' ) ) );

	}

	/**
	 * Get post views count.
	 *
	 * @since    1.0.0
	 */
	public function get_post_views( $postID ) {

		$post_view_meta_key = '_milkit_framework_post_views_count';
		$count = get_post_meta( $postID, $post_view_meta_key, true );

		if ( $count == '' ) {
			delete_post_meta( $postID, $post_view_meta_key );
			add_post_meta( $postID, $post_view_meta_key, '0' );
			return "0";
		}

		return $count;

	}

	/**
	 * Display the post views count in the column.
	 *
	 * @since    1.0.0
	 */
	public function manage_posts_custom_column( $column, $postID ) {

		if ( $column === 'milkit_framework_post_views' ) {
			echo $this->get_post_views( $postID );
		}

	}

	/**
	 * Meta box utility: case select.
	 *
	 * @since    1.0.0
	 */
	public function meta_box_select( $type, $id, $std, $name, $desc, $options, $meta ) {

		$val = $meta ? $meta : $std;
		echo '<div class="section section-' . $type . ' section-' . $id . '">';
		echo '<h4 class="heading">' . $name . '</h4>';
		echo '<div class="option">';
		echo '<div class="command">';
		echo'<select id="' . $id . '" name="' . $id . '">';
		foreach ( $options as $option ) {
			echo'<option';
			if ( $meta == $option ) { 
				echo ' selected="selected"'; 
			}
			echo'>' . $option . '</option>';
		} 
		echo'</select>';
		echo '<br></div>';
		if ( $desc != '' ) {
			echo '<p class="desc">' . $desc . '</p>';
		}
		echo '</div>';
		echo '</div>';

	}

	/**
	 * Meta box utility: case text.
	 *
	 * @since    1.0.0
	 */
	public function meta_box_text( $type, $id, $std, $name, $desc, $meta ) {

		$val = $meta ? $meta : $std;
		echo '<div class="section section-' . $type . ' section-' . $id . '">';
		echo '<h4 class="heading">' . $name . '</h4>';
		echo '<div class="option">';
		echo '<div class="command">';
		echo '<input type="text" name="' . $id . '" id="' . $id . '" value="' . esc_attr( $val ) . '">';
		echo '<br></div>';
		if ( $desc != '' ) {
			echo '<p class="desc">' . $desc . '</p>';
		}
		echo '</div>';
		echo '</div>';

	}

	/**
	 * Meta box utility: case textarea.
	 *
	 * @since    1.0.0
	 */
	public function meta_box_textarea( $type, $id, $std, $name, $desc, $meta ) {

		$val = $meta ? $meta : $std;
		echo '<div class="section section-' . $type . ' section-' . $id . '">';
		echo '<h4 class="heading">' . $name . '</h4>';
		echo '<div class="option">';
		echo '<div class="command">';
		echo '<textarea name="' . $id . '" id="' . $id . '" value="' . esc_attr( $val ) . '" cols="40" rows="4">' . $val . '</textarea>';
		echo '<br></div>';
		echo '</div>';
		echo '</div>';

	}

	/**
	 * Meta box utility: case rating.
	 *
	 * @since    1.0.0
	 */
	public function meta_box_rating( $type, $id_score, $id_pros, $id_cons, $name, $score, $pros, $cons ) {

		echo '<div class="section section-' . $type . '">';
		echo '<h4 class="heading">' . $name . '</h4>';
		echo '<div class="option">';
		echo '<div class="command">';

		echo '<div class="section-score">';

		if ( is_array( $score ) ) {
			foreach ( $score as $key => $value ) {
				echo '<div class="review-score">';
				echo '<span class="input-label">' . __( 'Rating', 'milkit-framework' ) . '</span>';
				echo '<input type="text" name="' . $id_score . '[' . $key . '][name]" class="review-score-name" value="' . esc_attr( $value[ 'name' ] ) . '">';
				echo '<div class="sep-input"></div>';
				echo '<span class="input-label">' . __( 'Score (1-5)', 'milkit-framework' ) . '</span>';
				echo '<input type="text" name="' . $id_score . '[' . $key . '][value]" class="review-score-value" value="' . esc_attr( $value[ 'value' ] ) . '">';
				echo '<a href="#" class="delete-score button">' . __( 'Delete', 'milkit-framework' ) . '</a>';
				echo '</div>';
			}
		} else {
			echo '<div class="review-score">';
			echo '<span class="input-label">' . __( 'Rating', 'milkit-framework' ) . '</span>';
			echo '<input type="text" name="' . $id_score . '[0][name]" class="review-score-name" value="">';
			echo '<div class="sep-input"></div>';
			echo '<span class="input-label">' . __( 'Score (1-5)', 'milkit-framework' ) . '</span>';
			echo '<input type="text" name="' . $id_score . '[0][value]" class="review-score-value" value="">';
			echo '<a href="#" class="delete-score button">' . __( 'Delete', 'milkit-framework' ) . '</a>';
			echo '</div>';
		}
		echo '<a href="#" class="add-score button button-primary">' . __( 'Add new rating', 'milkit-framework' ) . '</a>';

		echo '</div>';

		echo '<div class="section-list">';

		echo '<div class="review-pros review-list">';
		if ( is_array( $pros ) ) {
			foreach ( $pros as $key => $value ) {
				echo '<div class="pros">';
				echo '<span class="input-label">' . __( 'Pros', 'milkit-framework' ) . '</span>';
				echo '<input type="text" name="' . $id_pros . '[' . $key . ']" class="review-list-pros" value="' . esc_attr( $value ) . '">';
				echo '<a href="#" class="delete-list button">' . __( 'Delete', 'milkit-framework' ) . '</a>';
				echo '</div>';
			}
		} else {
			echo '<div class="pros">';
			echo '<span class="input-label">' . __( 'Pros', 'milkit-framework' ) . '</span>';
			echo '<input type="text" name="' . $id_pros . '[0]" class="review-list-pros" value="">';
			echo '<a href="#" class="delete-list button">' . __( 'Delete', 'milkit-framework' ) . '</a>';
			echo '</div>';
		}
		echo '<a href="#" class="add-pros button button-primary">' . __( 'Add new pros', 'milkit-framework' ) . '</a>';
		echo '</div>';

		echo '<div class="review-cons review-list">';
		if ( is_array( $cons ) ) {
			foreach ( $cons as $key => $value ) {
				echo '<div class="cons">';
				echo '<span class="input-label">' . __( 'Cons', 'milkit-framework' ) . '</span>';
				echo '<input type="text" name="' . $id_cons . '[' . $key . ']" class="review-list-cons" value="' . esc_attr( $value ) . '">';
				echo '<a href="#" class="delete-list button">' . __( 'Delete', 'milkit-framework' ) . '</a>';
				echo '</div>';
			}
		} else {
			echo '<div class="cons">';
			echo '<span class="input-label">' . __( 'Cons', 'milkit-framework' ) . '</span>';
			echo '<input type="text" name="' . $id_cons . '[0]" class="review-list-cons" value="">';
			echo '<a href="#" class="delete-list button">' . __( 'Delete', 'milkit-framework' ) . '</a>';
			echo '</div>';
		}
		echo '<a href="#" class="add-cons button button-primary">' . __( 'Add new cons', 'milkit-framework' ) . '</a>';
		echo '</div>';

		echo '</div>';

		echo '</div>';
		echo '</div>';
		echo '</div>';

	}

	/**
	 * Meta box utility: case upload-gallery.
	 *
	 * @since    1.0.0
	 */
	public function meta_box_upload_gallery( $type, $id, $std, $name, $desc, $meta ) {

		$val = $meta ? $meta : $std;
		echo '<div class="section section-' . $type . ' section-' . $id . '">';
		echo '<h4 class="heading">' . $name . '</h4>';
		echo '<div class="option">';
		echo '<div class="command">';
		echo '<input type="text" name="' . $id . '" id="' . $id . '" value="' . esc_attr( $val ) . '">';
		echo '<br>';
		echo '<a href="#" class="upload-button-gallery button-primary">' . __( 'Select images', 'milkit-framework' ) . '</a>';
		echo '<br></div>';
		if ( $desc != '' ) {
			echo '<p class="desc">' . $desc . '</p>';
		}
		echo '</div>';
		echo '</div>';

	}

	/**
	 * Meta boxes: general.
	 *
	 * @since    1.1.0
	 */
	public function add_meta_boxes_general() {

		$prefix = 'milkit_meta_';

		$this->meta_boxes_general = array(
			'id' => 'milkit-framework-meta-box-general',
			'title' => __('Post settings', 'milkit-framework' ),
			'page' => 'post',
			'context' => 'normal',
			'priority' => 'high',
			'fields' => array(
				array(
					'name' =>  __( 'Use for slider in homepage?', 'milkit-framework' ),
					'id' => $prefix . 'home_slider',
					'options' => array( 'no', 'yes' ),
					'desc' => '',
					'type' => 'select',
					'std' => 'no'
				),
				array(
					'name' =>  __( 'Is this post a review?', 'milkit-framework' ),
					'id' => $prefix . 'review_type',
					'options' => array( 'no', 'list', 'score' ),
					'desc' => '',
					'type' => 'select',
					'std' => 'no'
				),
				array(
					'name' =>  __( 'Add ratings to this review', 'milkit-framework' ),
					'id_score' => $prefix . 'review_score',
					'id_pros' => $prefix . 'review_pros',
					'id_cons' => $prefix . 'review_cons',
					'type' => 'rating'
				),
				array(
					'name' =>  __( 'Pros label', 'milkit-framework' ),
					'id' => $prefix . 'review_pros_label',
					'desc' => '',
					'type' => 'text',
					'std' => 'What we liked'
				),
				array(
					'name' =>  __( 'Cons label', 'milkit-framework' ),
					'id' => $prefix . 'review_cons_label',
					'desc' => '',
					'type' => 'text',
					'std' => 'What we didn\'t like'
				),
				array(
					'name' =>  __( 'Review score', 'milkit-framework' ),
					'id' => $prefix . 'review_final_score',
					'desc' => __( 'Select the total score of this review (a value from 1 to 5).', 'milkit-framework' ),
					'type' => 'text',
					'std' => ''
				),
				array(
					'name' =>  __( 'Review score text', 'milkit-framework' ),
					'id' => $prefix . 'review_final_score_text',
					'desc' => __( 'Type the verdict of the review (excellent, great, etc).', 'milkit-framework' ),
					'type' => 'text',
					'std' => ''
				),
				array(
					'name' =>  __( 'Review label', 'milkit-framework' ),
					'id' => $prefix . 'review_label',
					'desc' => '',
					'type' => 'text',
					'std' => 'Verdict'
				),
				array(
					'name' =>  __( 'Review description', 'milkit-framework' ),
					'id' => $prefix . 'review_description',
					'desc' => '',
					'type' => 'textarea',
					'std' => ''
				),
				array(
					'name' =>  __( 'Item type reviewed?', 'milkit-framework' ),
					'id' => $prefix . 'review_item',
					'desc' => __( 'The type of the item (book, movie, product, etc). More info in <a href="http://schema.org/Review">schema.org</a>. Thing is the most generic type of item. Please note: I don\'t provide support for questions related to the microdata specification. Please use schema.org for that.', 'milkit-framework' ),
					'type' => 'text',
					'std' => 'Thing'
				),
			)
		);
	}

	/**
	 * Meta boxes: general fields.
	 *
	 * @since    1.0.0
	 */
	public function meta_boxes_general_fields() {
		global $post;

		wp_nonce_field( 'milkit_framework_meta_box_nonce', 'milkit_meta_box_nonce' );

		echo '<div class="wrap-boxes">';

		foreach ( $this->meta_boxes_general[ 'fields' ] as $field ) {

			switch ( $field[ 'type' ] ) {

				case 'select':
					$meta = get_post_meta( $post->ID, $field[ 'id' ], true );
					$this->meta_box_select( $field[ 'type' ], $field[ 'id' ], $field[ 'std' ], $field[ 'name' ], $field[ 'desc' ], $field[ 'options' ], $meta );
				break;

				case 'textarea':
					$meta = get_post_meta( $post->ID, $field[ 'id' ], true );
					$this->meta_box_textarea( $field[ 'type' ], $field[ 'id' ], $field[ 'std' ], $field[ 'name' ], $field[ 'desc' ], $meta );
				break;

				case 'text':
					$meta = get_post_meta( $post->ID, $field[ 'id' ], true );
					$this->meta_box_text( $field[ 'type' ], $field[ 'id' ], $field[ 'std' ], $field[ 'name' ], $field[ 'desc' ], $meta );
				break;

				case 'rating':
					$score = get_post_meta( $post->ID, $field[ 'id_score' ], true );
					$pros = get_post_meta( $post->ID, $field[ 'id_pros' ], true );
					$cons = get_post_meta( $post->ID, $field[ 'id_cons' ], true );
					$this->meta_box_rating( $field[ 'type' ], $field[ 'id_score' ], $field[ 'id_pros' ], $field[ 'id_cons' ], $field[ 'name' ], $score, $pros, $cons );
				break;

			}
		}

		echo '</div>';
	}

	/**
	 * Meta boxes: gallery.
	 *
	 * @since    1.0.0
	 */
	public function add_meta_boxes_gallery() {

		$prefix = 'milkit_meta_';

		$this->meta_boxes_gallery = array(
			'id' => 'milkit-framework-meta-box-gallery',
			'title' => __('Gallery settings', 'milkit-framework' ),
			'page' => 'post',
			'context' => 'normal',
			'priority' => 'high',
			'fields' => array(
				array(
					'name' =>  __( 'Insert custom gallery?', 'milkit-framework' ),
					'id' => $prefix . 'custom_gallery_check',
					'options' => array( 'no', 'yes' ),
					'desc' => '',
					'type' => 'select',
					'std' => 'no'
				),
				array(
					'name' =>  __( 'Gallery images', 'milkit-framework' ),
					'id' => $prefix . 'custom_gallery',
					'desc' => __( 'Upload/select the images you want to include in this gallery (hold down the CTRL/CMD key to select mutiple files).', 'milkit-framework' ),
					'type' => 'upload-gallery',
					'std' => ''
				),
				array(
					'name' =>  __( 'Gallery title', 'milkit-framework' ),
					'id' => $prefix . 'custom_gallery_title',
					'desc' => __( 'Insert a custom title for the gallery or leave the field empty to hide it.', 'milkit-framework' ),
					'type' => 'text',
					'std' => ''
				),
				array(
					'name' =>  __( 'Gallery description', 'milkit-framework' ),
					'id' => $prefix . 'custom_gallery_desc',
					'desc' => __( 'Write a little description of the gallery or leave the field empty to hide it.', 'milkit-framework' ),
					'type' => 'textarea',
					'std' => ''
				)
			)
		);
	}

	/**
	 * Meta boxes: gallery fields.
	 *
	 * @since    1.0.0
	 */
	public function meta_boxes_gallery_fields() {
		global $post;

		wp_nonce_field( 'milkit_framework_meta_box_nonce', 'milkit_meta_box_nonce' );

		echo '<div class="wrap-boxes">';

		foreach ( $this->meta_boxes_gallery[ 'fields' ] as $field ) {

			switch ( $field[ 'type' ] ) {

				case 'select':
					$meta = get_post_meta( $post->ID, $field[ 'id' ], true );
					$this->meta_box_select( $field[ 'type' ], $field[ 'id' ], $field[ 'std' ], $field[ 'name' ], $field[ 'desc' ], $field[ 'options' ], $meta );
				break;

				case 'upload-gallery':
					$meta = get_post_meta( $post->ID, $field[ 'id' ], true );
					$this->meta_box_upload_gallery( $field[ 'type' ], $field[ 'id' ], $field[ 'std' ], $field[ 'name' ], $field[ 'desc' ], $meta );
				break;

				case 'text':
					$meta = get_post_meta( $post->ID, $field[ 'id' ], true );
					$this->meta_box_text( $field[ 'type' ], $field[ 'id' ], $field[ 'std' ], $field[ 'name' ], $field[ 'desc' ], $meta );
				break;

				case 'textarea':
					$meta = get_post_meta( $post->ID, $field[ 'id' ], true );
					$this->meta_box_textarea( $field[ 'type' ], $field[ 'id' ], $field[ 'std' ], $field[ 'name' ], $field[ 'desc' ], $meta );
				break;

			}
		}

		echo '</div>';
	}

	/**
	 * Meta boxes: display fields.
	 *
	 * @since    1.0.0
	 */
	public function display_meta_boxes() {

		add_meta_box( $this->meta_boxes_general['id'], $this->meta_boxes_general['title'], array( $this, 'meta_boxes_general_fields' ), $this->meta_boxes_general['page'], $this->meta_boxes_general['context'], $this->meta_boxes_general['priority'] );
		add_meta_box( $this->meta_boxes_gallery['id'], $this->meta_boxes_gallery['title'], array( $this, 'meta_boxes_gallery_fields' ), $this->meta_boxes_gallery['page'], $this->meta_boxes_gallery['context'], $this->meta_boxes_gallery['priority'] );

	}

	/**
	 * Meta boxes: save fields.
	 *
	 * @since    1.0.0
	 */
	public function save_meta_boxes( $post_id ) {

		if ( ! isset( $_POST[ 'milkit_meta_box_nonce' ] ) ) {
			return $post_id;
		}

		$nonce = $_POST[ 'milkit_meta_box_nonce' ];

		if ( ! wp_verify_nonce( $nonce, 'milkit_framework_meta_box_nonce' ) ) {
			return $post_id;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}

		foreach ( $this->meta_boxes_general[ 'fields' ] as $field ) {

			if ( $field[ 'type' ] == 'rating' ) {

				$score = isset( $_POST[ 'milkit_meta_review_score' ] ) ? ( array ) $_POST[ 'milkit_meta_review_score' ] : array();
				foreach ( $score as $val ) {
					$val = array_map( 'sanitize_text_field', $val );
				}
				update_post_meta( $post_id, $field[ 'id_score' ], $score );

				$pros = isset( $_POST[ 'milkit_meta_review_pros' ] ) ? ( array ) $_POST[ 'milkit_meta_review_pros' ] : array();
				$pros = array_map( 'sanitize_text_field', $pros );
				update_post_meta( $post_id, $field[ 'id_pros' ], $pros );

				$cons = isset( $_POST[ 'milkit_meta_review_cons' ] ) ? ( array ) $_POST[ 'milkit_meta_review_cons' ] : array();
				$cons = array_map( 'sanitize_text_field', $cons );
				update_post_meta( $post_id, $field[ 'id_cons' ], $cons );

			} else {

				$data = sanitize_text_field( $_POST[ $field[ 'id' ] ] );
				update_post_meta( $post_id, $field[ 'id' ], $data );

			}

		}

		foreach ( $this->meta_boxes_gallery[ 'fields' ] as $field ) {

			$data = sanitize_text_field( $_POST[ $field[ 'id' ] ] );
			update_post_meta( $post_id, $field[ 'id' ], $data );

		}

	}

}

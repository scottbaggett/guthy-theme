(function( $ ) {
	'use strict';

	$(function() {

		function set_name_attr( el, name, index, val ) {
			el.prop( 'name', name + '[' + index + ']' + '[' + val + ']' );
		}

		function set_name_attr_single( el, name, index ) {
			el.prop( 'name', name + '[' + index + ']' );
		}

		$( '.section-rating' ).hide();
		$( '.section-score' ).hide();
		$( '.section-list' ).hide();
		$( '.section-milkit_meta_review_final_score' ).hide();
		$( '.section-milkit_meta_review_final_score_text' ).hide();
		$( '.section-milkit_meta_review_pros_label' ).hide();
		$( '.section-milkit_meta_review_cons_label' ).hide();
		$( '.section-milkit_meta_review_label' ).hide();
		$( '.section-milkit_meta_review_description' ).hide();
		$( '.section-milkit_meta_review_item' ).hide();
		$( '.section-milkit_meta_custom_gallery' ).hide();
		$( '.section-milkit_meta_custom_gallery_title' ).hide();
		$( '.section-milkit_meta_custom_gallery_desc' ).hide();

		if ( $( '#milkit_meta_review_type' ).val() ) {
			if ( $( '#milkit_meta_review_type' ).val() === 'score' ) {
				$( '.section-rating' ).show();
				$( '.section-score' ).show();
				$( '.section-milkit_meta_review_label' ).show();
				$( '.section-milkit_meta_review_description' ).show();
				$( '.section-milkit_meta_review_item' ).show();
				$( '.section-milkit_meta_review_final_score_text' ).show();
			} else if ( $( '#milkit_meta_review_type' ).val() === 'list' ) {
				$( '.section-rating' ).show();
				$( '.section-list' ).show();
				$( '.section-milkit_meta_review_base' ).show();
				$( '.section-milkit_meta_review_pros_label' ).show();
				$( '.section-milkit_meta_review_cons_label' ).show();
				$( '.section-milkit_meta_review_final_score' ).show();
				$( '.section-milkit_meta_review_label' ).show();
				$( '.section-milkit_meta_review_description' ).show();
				$( '.section-milkit_meta_review_item' ).show();
				$( '.section-milkit_meta_review_final_score_text' ).show();
			}
		}

		$( '#milkit_meta_review_type' ).change( function() {
			if ( $( this ).val() === 'score') {
				$( '.section-rating' ).show();
				$( '.section-score' ).show();
				$( '.section-list' ).hide();
				$( '.section-milkit_meta_review_pros_label' ).hide();
				$( '.section-milkit_meta_review_cons_label' ).hide();
				$( '.section-milkit_meta_review_final_score' ).hide();
				$( '.section-milkit_meta_review_label' ).show();
				$( '.section-milkit_meta_review_description' ).show();
				$( '.section-milkit_meta_review_item' ).show();
				$( '.section-milkit_meta_review_final_score_text' ).show();
			} else if ( $( this ).val() === 'list') {
				$( '.section-rating' ).show();
				$( '.section-score' ).hide();
				$( '.section-list' ).show();
				$( '.section-milkit_meta_review_pros_label' ).show();
				$( '.section-milkit_meta_review_cons_label' ).show();
				$( '.section-milkit_meta_review_final_score' ).show();
				$( '.section-milkit_meta_review_label' ).show();
				$( '.section-milkit_meta_review_description' ).show();
				$( '.section-milkit_meta_review_item' ).show();
				$( '.section-milkit_meta_review_final_score_text' ).show();
			} else {
				$( '.section-rating' ).hide();
				$( '.section-score' ).hide();
				$( '.section-list' ).hide();
				$( '.section-milkit_meta_review_pros_label' ).hide();
				$( '.section-milkit_meta_review_cons_label' ).hide();
				$( '.section-milkit_meta_review_final_score' ).hide();
				$( '.section-milkit_meta_review_label' ).hide();
				$( '.section-milkit_meta_review_description' ).hide();
				$( '.section-milkit_meta_review_item' ).hide();
				$( '.section-milkit_meta_review_final_score_text' ).hide();
			}
		});

		if ( $( '#milkit_meta_custom_gallery_check' ).val() ) {
			if ( $( '#milkit_meta_custom_gallery_check' ).val() === 'yes' ) {
				$( '.section-milkit_meta_custom_gallery' ).show();
				$( '.section-milkit_meta_custom_gallery_title' ).show();
				$( '.section-milkit_meta_custom_gallery_desc' ).show();
			} else {
				$( '.section-milkit_meta_custom_gallery' ).hide();
				$( '.section-milkit_meta_custom_gallery_title' ).hide();
				$( '.section-milkit_meta_custom_gallery_desc' ).hide();
			}
		}

		$( '#milkit_meta_custom_gallery_check' ).change( function() {
			if ( $( this ).val() === 'yes') {
				$( '.section-milkit_meta_custom_gallery' ).show();
				$( '.section-milkit_meta_custom_gallery_title' ).show();
				$( '.section-milkit_meta_custom_gallery_desc' ).show();
			} else {
				$( '.section-milkit_meta_custom_gallery' ).hide();
				$( '.section-milkit_meta_custom_gallery_title' ).hide();
				$( '.section-milkit_meta_custom_gallery_desc' ).hide();
			}
		});

		$( '.section-score' ).on( 'click', '.add-score', function( e ) {

			e.preventDefault();

			var rating_container = $( this ).parents( '.section-score' );
			var rating_html = rating_container.find( '.review-score' ).first();
			var rating_clone = rating_html.clone();

			rating_clone.find( 'input[type=text]' ).val('');

			if ( rating_clone ) {
				$( this ).before( rating_clone );
			}

			rating_container.find( '.review-score' ).each( function( index ) {

				var score_name_input = $( this ).find( '.review-score-name' );
				var score_value_input = $( this ).find( '.review-score-value' );
				set_name_attr( score_name_input, 'milkit_meta_review_score', index, 'name' );
				set_name_attr( score_value_input, 'milkit_meta_review_score', index, 'value' );
				
			});

		});

		$( '.section-score' ).on( 'click', '.delete-score', function( e ) {

			e.preventDefault();

			var rating_container = $( this ).parent();

			rating_container.remove();

		});

		$( '.review-pros' ).on( 'click', '.add-pros', function( e ) {

			e.preventDefault();

			var pros_container = $( this ).parents( '.review-pros' );
			var pros_html = pros_container.find( '.pros' ).first();
			var pros_clone = pros_html.clone();

			pros_clone.find( 'input[type=text]' ).val('');

			if ( pros_clone ) {
				$( this ).before( pros_clone );
			}

			pros_container.find( '.pros' ).each( function( index ) {

				var pros_input = $( this ).find( '.review-list-pros' );
				set_name_attr_single( pros_input, 'milkit_meta_review_pros', index );
				
			});

		});

		$( '.review-cons' ).on( 'click', '.add-cons', function( e ) {

			e.preventDefault();

			var cons_container = $( this ).parents( '.review-cons' );
			var cons_html = cons_container.find( '.cons' ).first();
			var cons_clone = cons_html.clone();

			cons_clone.find( 'input[type=text]' ).val('');

			if ( cons_clone ) {
				$( this ).before( cons_clone );
			}

			cons_container.find( '.cons' ).each( function( index ) {

				var cons_input = $( this ).find( '.review-list-cons' );
				set_name_attr_single( cons_input, 'milkit_meta_review_cons', index );
				
			});

		});

		$( '.section-list' ).on( 'click', '.delete-list', function( e ) {

			e.preventDefault();

			var list_container = $( this ).parent();
			
			list_container.remove();

		});

		$( '.section-upload-gallery' ).on('click', '.upload-button-gallery', function( e ) { 

			e.preventDefault();

			var image_gallery_ids = $(this).prev().prev();
			var file_frame;
			var attachment_ids = '';
	 
			// If the media frame already exists, reopen it.
			if ( file_frame ) {
				file_frame.open();
				return;
			}
	 
			// Create the media frame.
			file_frame = wp.media.frames.file_frame = wp.media({
				title: 'Create a gallery',
				button: {
					text: 'Create a gallery',
				},
				states : [
					new wp.media.controller.Library({
						title: 'title',
						filterable :	'all',
						multiple: true,
					})
				]
			});
	 
			// When an image is selected, run a callback.
			file_frame.on( 'select', function() {

				var file_path = '';
				var selection = file_frame.state().get('selection');

				selection.map( function( attachment ) {

					attachment = attachment.toJSON();

					if ( attachment.id ) {
						attachment_ids = attachment_ids ? attachment_ids + "," + attachment.id : attachment.id;
					}


					image_gallery_ids.val( '[milkit_gallery ids="' + attachment_ids + '"]');

				});

			});
	 
			// Finally, open the modal
			file_frame.open();

		});
		
	});

})( jQuery );

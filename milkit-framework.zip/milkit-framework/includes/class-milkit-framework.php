<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the dashboard.
 *
 * @since      1.0.0
 *
 * @package    Milkit_Framework
 * @subpackage Milkit_Framework/includes
 */

class Milkit_Framework {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Milkit_Framework_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $milkit_framework    The string used to uniquely identify this plugin.
	 */
	protected $milkit_framework;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the Dashboard and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {

		$this->milkit_framework = 'milkit-framework';
		$this->version = '1.0.0';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Milkit_Framework_Loader. Orchestrates the hooks of the plugin.
	 * - Milkit_Framework_i18n. Defines internationalization functionality.
	 * - Milkit_Framework_Admin. Defines all hooks for the dashboard.
	 * - Milkit_Framework_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-milkit-framework-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-milkit-framework-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the Dashboard.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-milkit-framework-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-milkit-framework-public.php';

		$this->loader = new Milkit_Framework_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Milkit_Framework_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Milkit_Framework_i18n();
		$plugin_i18n->set_domain( $this->get_milkit_framework() );

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the dashboard functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Milkit_Framework_Admin( $this->get_milkit_framework(), $this->get_version() );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

		if ( get_option( 'milkit_opt_check_post_counter' ) == 'true' ) {
			$this->loader->add_filter( 'manage_posts_columns', $plugin_admin, 'manage_posts_columns' );
			$this->loader->add_action( 'manage_posts_custom_column', $plugin_admin, 'manage_posts_custom_column', 10, 2 );
		}
		
		$this->loader->add_action( 'add_meta_boxes', $plugin_admin, 'display_meta_boxes', 10, 2 );
		$this->loader->add_action( 'save_post', $plugin_admin, 'save_meta_boxes', 10, 2 );
		
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Milkit_Framework_Public( $this->get_milkit_framework(), $this->get_version() );

		$this->loader->add_action( 'milkit_post_sharer', $plugin_public, 'sharer', 10, 2 );
		$this->loader->add_action( 'milkit_post_review', $plugin_public, 'show_post_review', 10, 2 );
		$this->loader->add_action( 'milkit_display_post_review_score', $plugin_public, 'show_icon_review', 10, 2 );
		$this->loader->add_action( 'milkit_custom_gallery', $plugin_public, 'show_custom_gallery', 10, 2 );

		/* Check if the post view counter is enabled */
		if ( get_option( 'milkit_opt_check_post_counter' ) == 'true' ) {

			$this->loader->add_action( 'milkit_update_post_views', $plugin_public, 'update_post_views', 10, 2 );
			$this->loader->add_action( 'milkit_display_post_views', $plugin_public, 'show_post_views', 10, 2 );
		}

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_milkit_framework() {
		return $this->milkit_framework;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Milkit_Framework_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}

=== Milkit Framework ===
Author: Lollum
Version: 1.2.0
Requires at least: 4.1
Tested up to: 4.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Extra functionality for the Milk-It theme.

== Description ==

The Milkit Framework plugin extends the functionality of the Milk-It theme by adding support for count views, reviews, custom gallery, social and more. The plugin is required by the Milk-It theme because it will extend the theme to function as you see in the demo.

== Installation ==

This plugin can be installed directly from your site.

When you activate the Milk-It theme you see a warning asking you to install the required plugin. Just click on the 'Begin installing plugin' button.

== Frequently Asked Questions ==

= What is this plugin and why do I need it? =

The Milkit Framework plugin extends the functionality of the Milk-It theme by adding support for count views, reviews, custom gallery, social and more. The plugin is required by the Milk-It theme because it will extend the theme to function as you see in the demo.

= Can I use this plugin with other themes? =

The Milkit Framework plugin was developed to extend the functionality of the Milk-It theme specifically. It is not a plugin meant for use with other themes.

== Changelog ==

= v1.2.0 - Apr 06, 2015 =
* Minor fix in gallery markup.

= v1.1.0 - Mar 18, 2015 =
* Meta box for slider in homepage.
* Languages updated.

= v1.0.0 - Mar 15, 2014 =
* First release.

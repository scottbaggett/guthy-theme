<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @since      1.0.0
 *
 * @package    Milkit_Framework
 * @subpackage Milkit_Framework/public
 */

class Milkit_Framework_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $milkit_framework    The ID of this plugin.
	 */
	private $milkit_framework;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @var      string    $milkit_framework       The name of the plugin.
	 * @var      string    $version    The version of this plugin.
	 */
	public function __construct( $milkit_framework, $version ) {

		$this->milkit_framework = $milkit_framework;
		$this->version = $version;

	}

	/**
	 * Update the views count when the post is viewed (only in single.php).
	 *
	 * @since    1.0.0
	 */
	public function update_post_views( $postID ) {

		global $page;
		$post_view_meta_key = '_milkit_framework_post_views_count';

		if ( is_single() && ( empty( $page ) || $page == 1 ) ) {

			$count = get_post_meta( $postID, $post_view_meta_key, true );

			if ( $count == '' ) {
				update_post_meta( $postID, $post_view_meta_key, 1 );
			} else {
				$count++;
				update_post_meta( $postID, $post_view_meta_key, $count );
			}

		}

	}

	/**
	 * Get post views count.
	 *
	 * @since    1.0.0
	 */
	public function get_post_views( $postID ) {

		$post_view_meta_key = '_milkit_framework_post_views_count';
		$count = get_post_meta( $postID, $post_view_meta_key, true );

		if ( $count == '' ) {
			delete_post_meta( $postID, $post_view_meta_key );
			add_post_meta( $postID, $post_view_meta_key, '0' );
			return "0";
		}

		return $count;

	}

	/**
	 * Show post views count.
	 *
	 * @since    1.0.0
	 */
	public function show_post_views( $postID ) {

		$count = $this->get_post_views( $postID );

		echo '<span class="post-views-count milkit-post-' . esc_attr( $postID ) . '">' . sprintf( __( '%s views', 'milkit-framework' ), intval( $count ) ) . '</span>';

	}

	/**
	 * Show the post sharer.
	 *
	 * @since    1.0.0
	 */
	public function sharer() { ?>

		<?php if ( get_option( 'milkit_opt_show_post_sharer')  == 'true' ) : ?>

		<ul class="post-sharer">

			<?php if ( get_option( 'milkit_opt_share_facebook')  == 'true' ) : ?>
				<li><a class="milkit-facebook-share" href="https://www.facebook.com/sharer/sharer.php?u=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-facebook"></i></a></li>
			<?php endif; ?>

			<?php if ( get_option( 'milkit_opt_share_twitter')  == 'true' ) : ?>
				<li><a class="milkit-twitter-share" href="https://twitter.com/share?text=<?php echo rawurlencode( get_the_title() ); ?>&amp;url=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-twitter"></i></a></li>
			<?php endif; ?>

			<?php if ( get_option( 'milkit_opt_share_google')  == 'true' ) : ?>
				<li><a class="milkit-google-share" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-google-plus"></i></a></li>
			<?php endif; ?>

			<?php if ( get_option( 'milkit_opt_share_linkedin')  == 'true' ) : ?>
				<li><a class="milkit-linkedin-share" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php the_permalink(); ?>&amp;title=<?php echo rawurlencode( get_the_title() ); ?>&amp;source=<?php echo esc_url( home_url() ); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-linkedin"></i></a></li>
			<?php endif; ?>

			<?php if ( get_option( 'milkit_opt_share_pinterest')  == 'true' ) : ?>
				<li><a class="milkit-pinterest-share" href="//pinterest.com/pin/create/button/?url=<?php echo get_permalink(); ?>&amp;media=<?php echo wp_get_attachment_url( get_post_thumbnail_id() ); ?>&amp;description=<?php echo rawurlencode( get_the_title() ); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-pinterest"></i></a></li>
			<?php endif; ?>

		</ul>

		<?php endif;
	}

	/**
	 * Show post review.
	 *
	 * @since    1.0.0
	 */
	public function show_post_review( $postID ) {

		if ( ( get_post_meta( $postID, 'milkit_meta_review_type', true ) != 'list' ) && ( get_post_meta( $postID, 'milkit_meta_review_type', true ) != 'score' ) ) {
			return;
		}

		$base = 5;
		?>

		<div class="post-review">

		<?php if ( get_post_meta( $postID, 'milkit_meta_review_type', true ) == 'score' ) :

			$scores = get_post_meta( $postID, 'milkit_meta_review_score', true ); ?>

			<?php
			$total = 0;
			?>
			
			<?php
			if ( is_array( $scores ) ) :
			foreach ( $scores as $score ) :

				$val = ( 100 * intval( $score[ 'value' ] ) ) / $base;
				$total +=  intval( $score[ 'value' ] );
				?>

				<div class="score">

					<span class="score-label"><?php echo esc_html( $score[ 'name' ] ); ?></span>
					<span class="score-label value"><span class="star-rating" title="<?php printf( __( 'Rated %s out of 5', 'milkit-framework' ), $score[ 'value' ] ); ?>"><span style="width:<?php echo ( ( $score[ 'value' ] / 5 ) * 100 ); ?>%"><?php echo esc_html( $score[ 'value' ] ); ?></span></span></span>

				</div>

			<?php
			endforeach;
			endif;

			if ( $total > 0 ) {
				$average = $total / count( $scores );
			} else {
				$average = 1;
			}
			?>

		<?php elseif ( get_post_meta( $postID, 'milkit_meta_review_type', true ) == 'list' ) :
			$pros = get_post_meta( $postID, 'milkit_meta_review_pros', true );
			$cons = get_post_meta( $postID, 'milkit_meta_review_cons', true );
			?>

			<?php if ( is_array( $pros ) ) : ?>

			<div class="review-list-wrap">

				<span class="pros-label"><?php echo esc_html( get_post_meta( $postID, 'milkit_meta_review_pros_label', true ) ); ?></span>

				<ul class="pros review-list">

					<?php foreach ( $pros as $value ) : ?>
						
					<li><?php echo esc_html( $value ); ?></li>

					<?php endforeach; ?>

				</ul>

			</div>

			<?php endif; ?>

			<?php if ( is_array( $cons ) ) : ?>

			<div class="review-list-wrap">

				<span class="cons-label"><?php echo esc_html( get_post_meta( $postID, 'milkit_meta_review_cons_label', true ) ); ?></span>

				<ul class="cons review-list">

					<?php foreach ( $cons as $value ) : ?>
						
					<li><?php echo esc_html( $value ); ?></li>

					<?php endforeach; ?>

				</ul>

			</div>

			<?php endif; ?>

			<?php
			$average = get_post_meta( $postID, 'milkit_meta_review_final_score', true ) ? get_post_meta( $postID, 'milkit_meta_review_final_score', true ) : 1;
			?>

		<?php endif; ?>

		<div class="review-summary">
			<div class="review-description">
				<h3><?php echo esc_html( get_post_meta( $postID, 'milkit_meta_review_label', true ) ); ?></h3>

				<p itemprop="description"><?php echo esc_html( get_post_meta( $postID, 'milkit_meta_review_description', true ) ); ?></p>	
			</div>
			<?php
			echo $this->show_review_markup( $postID, get_post_meta( $postID, 'milkit_meta_review_item', true ), $average, $base, get_post_meta( $postID, 'milkit_meta_review_final_score_text', true ) );
			?>
		</div>

		</div><!-- .post-review -->

		<?php

	}

	/**
	 * Show icon review.
	 *
	 * @since    1.0.0
	 */
	public function show_icon_review( $postID ) {

		if ( ( get_post_meta( $postID, 'milkit_meta_review_type', true ) != 'list' ) && ( get_post_meta( $postID, 'milkit_meta_review_type', true ) != 'score' ) ) {
			return;
		}

		$base = 5;
		?>

		<div class="icon-review">

		<?php if ( get_post_meta( $postID, 'milkit_meta_review_type', true ) == 'score' ) :

			$scores = get_post_meta( $postID, 'milkit_meta_review_score', true );
			$total = 0;

			if ( is_array( $scores ) ) :
			foreach ( $scores as $score ) :

				$val = ( 100 * intval( $score[ 'value' ] ) ) / $base;
				$total +=  intval( $score[ 'value' ] );

			endforeach;
			endif;

			if ( $total > 0 ) {
				$average = $total / count( $scores );
			} else {
				$average = 1;
			}

		elseif ( get_post_meta( $postID, 'milkit_meta_review_type', true ) == 'list' ) :

			$pros = get_post_meta( $postID, 'milkit_meta_review_pros', true );
			$cons = get_post_meta( $postID, 'milkit_meta_review_cons', true );
			$average = get_post_meta( $postID, 'milkit_meta_review_final_score', true ) ? get_post_meta( $postID, 'milkit_meta_review_final_score', true ) : 1;

		endif;

		echo $this->show_review_markup( $postID, get_post_meta( $postID, 'milkit_meta_review_item', true ), $average, $base ); ?>

		</div><!-- .icon-review -->

		<?php

	}

	/**
	 * Review microdata markup.
	 *
	 * @since    1.0.0
	 */
	public function show_review_markup( $postID, $type, $vote_average, $vote_base, $score_text = false ) {

		$output = '<div itemscope="itemscope" itemtype="http://schema.org/Review">';
		$output .= '<div itemprop="reviewRating" itemscope="itemscope" itemtype="http://schema.org/Rating" class="review-score">';
		$output .= '<span class="star-rating" title="' . sprintf( __( 'Rated %s out of 5', 'milkit-framework' ), $vote_average ) . '"><span style="width:' . esc_attr( ( $vote_average / 5 ) * 100 ) . '%">' . esc_attr( floor( ( $vote_average * 10 ) ) / 10 ) . '</span></span>';
		if ( $score_text ) {
			$output .= '<span class="score-text">' . esc_html( $score_text ) . '</span>';
		}
		$output .= '<meta itemprop="ratingValue" content="' . esc_attr( $vote_average ) . '">';
		$output .= '<meta itemprop="bestRating" content="' . esc_attr( $vote_base ) . '">';
		$output .= '<meta itemprop="worstRating" content="1">';
		$output .= '</div>';
		$output .= '<span class="semantic" itemprop="itemreviewed" itemscope="itemscope" itemtype="http://schema.org/' . esc_attr( $type ) . '"><span itemprop="name">' . get_the_title() . '</span></span>';
		$output .= '<div class="semantic" itemprop="author" itemscope="itemscope" itemtype="http://schema.org/Person">';
		$output .= '<span itemprop="name">' . esc_html( get_the_author() ) . '</span>';
		$output .= '</div>';
		$output .= '</div>';

		return apply_filters( 'show_review_markup_filter', $output );

	}

	/**
	 * Show custom gallery.
	 *
	 * @since    1.0.0
	 */
	public function show_custom_gallery( $postID ) {

		if ( get_post_meta( $postID, 'milkit_meta_custom_gallery_check', true ) == 'no' ) {
			return;
		}

		$shortcode = get_post_meta( $postID, 'milkit_meta_custom_gallery', true );

		if ( preg_match( '/\[milkit_gallery.*ids=.(.*).\]/', $shortcode, $matches ) ) {
			$images = explode( ",", $matches[ 1 ] );
			?>

			<div class="milkit-gallery" itemscope="itemscope" itemtype="http://schema.org/ImageGallery">

			<?php

			if ( get_post_meta( $postID, 'milkit_meta_custom_gallery_title', true ) != '' ) : ?>

				<h4><?php echo esc_html( get_post_meta( $postID, 'milkit_meta_custom_gallery_title', true ) ); ?></h4>

			<?php endif;

			if ( get_post_meta( $postID, 'milkit_meta_custom_gallery_desc', true ) != '' ) : ?>

				<p><?php echo esc_html( get_post_meta( $postID, 'milkit_meta_custom_gallery_desc', true ) ); ?></p>

			<?php endif; ?>

			<div class="milkit-gallery-images">

			<?php foreach ( $images as $image ) {

				$attachment = get_post( intval( $image ) );
				$alt = get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );
				$caption = $attachment->post_excerpt;
				$author = $attachment->post_author;
				$src = wp_get_attachment_image_src( $image, 'milkit_248x158' );
				$src_large = wp_get_attachment_image_src( $image, 'full' ); ?>

				<figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
					<a href="<?php echo esc_url( $src_large[ 0 ] ); ?>" itemprop="contentUrl" data-size="<?php echo esc_attr( $src_large[ 1 ] ) ?>x<?php echo esc_attr( $src_large[ 2 ] ) ?>" data-author="<?php bloginfo( 'name' ); ?>">
						<img src="<?php echo esc_url( $src[ 0 ] ); ?>" itemprop="thumbnail" alt="<?php echo esc_attr( $alt ); ?>" width="<?php echo esc_attr( $src[ 1 ] ); ?>" height="<?php echo esc_attr( $src[ 2 ] ); ?>">
					</a>

					<figcaption itemprop="caption description">
						<?php echo esc_html( $caption ); ?>
					</figcaption>

					<meta itemprop="copyrightHolder" content="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
					<meta itemprop="width" content="<?php echo esc_attr( $src[ 1 ] ); ?>">
					<meta itemprop="height" content="<?php echo esc_attr( $src[ 2 ] ); ?>">
				</figure>

			<?php } ?>

			</div>
			
			</div>

		<?php
		}

	}

}
